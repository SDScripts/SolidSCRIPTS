Config = {} 

Config.Item = "scrap, door, fender"

Config.Locations = {
 Ped = vector4(-421.8859, -1689.0726, 18.0291, 41.10), -- SCRAP LOCATION
}

Config.Notify = {
 ----------------------------------------------------
 label = "Scrapyard", - YOU CAN EDIT YOUR LANGUAGE
 ----------------------------------------------------
 targetlabel = "Scrap Vehicle",
 progresslabel = "Scraping Vehicle..." 
 ----------------------------------------------------
}

Config.SellShops = {
    { 
        coords = vec3(411.44, 313.27, 103.01-0.9), -- Coords of sell shop
        heading = 201.2, -- Heading of ped in pawn shop
        ped = 'a_m_m_og_boss_01', -- Ped model name
        label = 'Sell Shop', -- Label at top of context menu/blip if enabled
        blip = {
            enabled = false, -- Enable blip?
            sprite = 11, 
            color = 11, 
            scale = 0.75 
        },
        items = {
            { item = 'scrap', label = 'Scrap', price = 250, currency = 'money' },
            { item = 'door', label = 'Door', price = 350, currency = 'money' },
            { item = 'fender', label = 'Fender', price = 450, currency = 'money' } 
        }
    },
}
